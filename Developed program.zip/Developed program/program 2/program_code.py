import pandas
pandas.read_json("2_Products.json").to_excel("output.xlsx")